NCDPI TABLEAU KIT
=================

On-brand icons for Tableau dashboards, from the NCDPI Data
Visualization Style Guide:
https://abax70.github.io/ncdpi-data-visualization-public/design-system/icons.html

The icon preview, usage rules, and the newest version of this kit are on
that page.


WHAT'S IN THIS FOLDER
---------------------

Shapes\                 Icons to use as mark shapes (Marks card > Shape).
  NCDPI Icons - Black   Use these when you want Tableau to color the icons
                        (put a field on Color). Tableau recolors black icons.
  NCDPI Icons - Navy    Fixed NCDPI navy (#003A70).
  NCDPI Icons - White   For navy or dark backgrounds. (They look blank in
                        Tableau's shape picker because the picker is white.)

Dashboard Images\       Files to place on a dashboard with an Image object.
  Icons - Navy          Icons for buttons, headers, and navigation.
  Icons - White         The same icons for navy or dark backgrounds.

The "@2x" in dashboard image filenames tells Tableau Desktop the image is
high-resolution, so it stays sharp on high-resolution screens. Keep the
suffix when you use these files.


HOW TO INSTALL THE SHAPES
-------------------------

1. Open File Explorer and go to:
      Documents\My Tableau Repository\Shapes
2. Copy the three "NCDPI Icons" folders from this kit's Shapes folder into
   that Shapes folder.
3. In Tableau, open the Shape menu on the Marks card. If Tableau was already
   open, click "Reload Shapes". The folders appear as palettes named
   "NCDPI Icons - Black", "- Navy", and "- White".

Shapes are saved inside your workbook, so people who open it don't need
this kit installed.


HOW TO USE THE DASHBOARD IMAGES
-------------------------------

On a dashboard, drag an Image object onto the canvas and choose a file from
the Dashboard Images folder. Keep the files somewhere permanent (not your
Downloads folder) so the workbook can find them.


RULES OF THUMB (from the NCDPI Web Style Guide)
-----------------------------------------------

- Use icons to help people navigate or act, not as decoration.
- One color per icon. Navy on white or pale blue, or white on navy.
- Stick to this one icon family in a dashboard; don't mix in other sets.
- An icon that is a button needs a text label or tooltip that says what it
  does.

NEED THE NCDPI LOGO?
--------------------

Logos aren't in this kit. The graphics team provides official Tableau-ready
logo files: graphics@dpi.nc.gov. Use them as they are -- don't recolor,
stretch, or retype them.


CREDITS
-------

Icons are from Bootstrap Icons (https://icons.getbootstrap.com), version
1.13.1, MIT License. See LICENSE-bootstrap-icons.txt.
